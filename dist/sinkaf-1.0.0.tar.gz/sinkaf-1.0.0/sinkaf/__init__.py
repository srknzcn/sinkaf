from sinkaf.sinkaf import Sinkaf
from sinkaf.utils import Preprocessor
__version__ = "0.0.1"